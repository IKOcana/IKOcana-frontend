export default function Dashboard() {
  return (
    <div className="p-4">
      <h2 className="text-2xl font-bold">Willkommen bei IKOcana</h2>
      <p className="mt-2">Du bist eingeloggt und siehst das geschützte Dashboard.</p>
    </div>
  );
}